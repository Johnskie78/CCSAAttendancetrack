"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { v4 as uuidv4 } from "uuid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getStudents, addStudent, updateStudent, deleteStudent, type Student } from "@/lib/db"
import { readFileAsDataURL } from "@/lib/qr-utils"
import { Pencil, Trash2, Plus, UserCheck, UserX, QrCode, Upload } from "lucide-react"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import QRCodeGenerator from "./qr-code-generator"

export default function StudentManagement() {
  const [students, setStudents] = useState<Student[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isQRDialogOpen, setIsQRDialogOpen] = useState(false)
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null)
  const [formData, setFormData] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    studentId: "",
    yearLevel: "",
    course: "",
    status: "active",
    photoUrl: "",
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    loadStudents()
  }, [])

  const loadStudents = async () => {
    try {
      const studentList = await getStudents()
      setStudents(studentList)
    } catch (error) {
      console.error("Error loading students:", error)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      try {
        const dataUrl = await readFileAsDataURL(file)
        setFormData({
          ...formData,
          photoUrl: dataUrl,
        })
      } catch (error) {
        console.error("Error reading file:", error)
      }
    }
  }

  const handleAddStudent = async () => {
    try {
      const newStudent: Student = {
        id: uuidv4(),
        firstName: formData.firstName,
        middleName: formData.middleName,
        lastName: formData.lastName,
        studentId: formData.studentId,
        yearLevel: formData.yearLevel,
        course: formData.course,
        status: formData.status as "active" | "inactive",
        photoUrl: formData.photoUrl || "/placeholder.svg?height=100&width=100",
      }

      await addStudent(newStudent)
      setIsAddDialogOpen(false)
      resetForm()
      loadStudents()
    } catch (error) {
      console.error("Error adding student:", error)
    }
  }

  const handleEditClick = (student: Student) => {
    setCurrentStudent(student)
    setFormData({
      firstName: student.firstName,
      middleName: student.middleName,
      lastName: student.lastName,
      studentId: student.studentId,
      yearLevel: student.yearLevel,
      course: student.course,
      status: student.status,
      photoUrl: student.photoUrl,
    })
    setIsEditDialogOpen(true)
  }

  const handleQRCodeClick = (student: Student) => {
    setCurrentStudent(student)
    setIsQRDialogOpen(true)
  }

  const handleUpdateStudent = async () => {
    if (!currentStudent) return

    try {
      const updatedStudent: Student = {
        ...currentStudent,
        firstName: formData.firstName,
        middleName: formData.middleName,
        lastName: formData.lastName,
        studentId: formData.studentId,
        yearLevel: formData.yearLevel,
        course: formData.course,
        status: formData.status as "active" | "inactive",
        photoUrl: formData.photoUrl || currentStudent.photoUrl,
      }

      await updateStudent(updatedStudent)
      setIsEditDialogOpen(false)
      setCurrentStudent(null)
      resetForm()
      loadStudents()
    } catch (error) {
      console.error("Error updating student:", error)
    }
  }

  const handleDeleteStudent = async (id: string) => {
    if (confirm("Are you sure you want to delete this student?")) {
      try {
        await deleteStudent(id)
        loadStudents()
      } catch (error) {
        console.error("Error deleting student:", error)
      }
    }
  }

  const resetForm = () => {
    setFormData({
      firstName: "",
      middleName: "",
      lastName: "",
      studentId: "",
      yearLevel: "",
      course: "",
      status: "active",
      photoUrl: "",
    })
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Student Management</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="text-base font-medium">
              <Plus className="mr-2 h-5 w-5" />
              Add Student
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle className="text-xl">Add New Student</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="flex justify-center mb-2">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarImage
                      src={formData.photoUrl || "/placeholder.svg?height=100&width=100"}
                      alt="Student photo"
                    />
                    <AvatarFallback className="text-lg">
                      {formData.firstName && formData.lastName
                        ? getInitials(formData.firstName, formData.lastName)
                        : "ST"}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute bottom-0 right-0 rounded-full h-8 w-8"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-base font-medium">
                    First Name
                  </Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="text-base h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="middleName" className="text-base font-medium">
                    Middle Name
                  </Label>
                  <Input
                    id="middleName"
                    name="middleName"
                    value={formData.middleName}
                    onChange={handleInputChange}
                    className="text-base h-11"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName" className="text-base font-medium">
                  Last Name
                </Label>
                <Input
                  id="lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  className="text-base h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="studentId" className="text-base font-medium">
                  Student ID
                </Label>
                <Input
                  id="studentId"
                  name="studentId"
                  value={formData.studentId}
                  onChange={handleInputChange}
                  className="text-base h-11"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="yearLevel" className="text-base font-medium">
                    Year Level
                  </Label>
                  <Select value={formData.yearLevel} onValueChange={(value) => handleSelectChange("yearLevel", value)}>
                    <SelectTrigger className="text-base h-11">
                      <SelectValue placeholder="Select Year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1st" className="text-base">
                        1st Year
                      </SelectItem>
                      <SelectItem value="2nd" className="text-base">
                        2nd Year
                      </SelectItem>
                      <SelectItem value="3rd" className="text-base">
                        3rd Year
                      </SelectItem>
                      <SelectItem value="4th" className="text-base">
                        4th Year
                      </SelectItem>
                      <SelectItem value="5th" className="text-base">
                        5th Year
                      </SelectItem>
                      <SelectItem value="Graduate" className="text-base">
                        Graduate
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="course" className="text-base font-medium">
                    Course
                  </Label>
                  <Input
                    id="course"
                    name="course"
                    value={formData.course}
                    onChange={handleInputChange}
                    className="text-base h-11"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status" className="text-base font-medium">
                  Status
                </Label>
                <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                  <SelectTrigger className="text-base h-11">
                    <SelectValue placeholder="Select Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active" className="text-base">
                      Active
                    </SelectItem>
                    <SelectItem value="inactive" className="text-base">
                      Inactive
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  resetForm()
                  setIsAddDialogOpen(false)
                }}
                className="text-base"
              >
                Cancel
              </Button>
              <Button onClick={handleAddStudent} className="text-base">
                Add Student
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg overflow-hidden shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-base font-semibold">Photo</TableHead>
              <TableHead className="text-base font-semibold">Name</TableHead>
              <TableHead className="text-base font-semibold">ID</TableHead>
              <TableHead className="text-base font-semibold">Year & Course</TableHead>
              <TableHead className="text-base font-semibold">Status</TableHead>
              <TableHead className="text-right text-base font-semibold">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-4 text-base">
                  No students found. Add a student to get started.
                </TableCell>
              </TableRow>
            ) : (
              students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={student.photoUrl} alt={`${student.firstName} ${student.lastName}`} />
                      <AvatarFallback className="text-base">
                        {getInitials(student.firstName, student.lastName)}
                      </AvatarFallback>
                    </Avatar>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-base">{`${student.lastName}, ${student.firstName} ${student.middleName ? student.middleName.charAt(0) + "." : ""}`}</div>
                  </TableCell>
                  <TableCell className="text-base">{student.studentId}</TableCell>
                  <TableCell className="text-base">{`${student.yearLevel} - ${student.course}`}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      {student.status === "active" ? (
                        <>
                          <UserCheck className="h-5 w-5 text-green-500 mr-2" />
                          <span className="text-green-600 text-base font-medium">Active</span>
                        </>
                      ) : (
                        <>
                          <UserX className="h-5 w-5 text-red-500 mr-2" />
                          <span className="text-red-600 text-base font-medium">Inactive</span>
                        </>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleQRCodeClick(student)}
                      title="Generate QR Code"
                      className="mr-2 text-base"
                    >
                      <QrCode className="h-4 w-4 mr-1" />
                      QR Code
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditClick(student)}
                      title="Edit Student"
                      className="mr-2 text-base"
                    >
                      <Pencil className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteStudent(student.id)}
                      title="Delete Student"
                      className="text-red-600 border-red-200 hover:bg-red-50 text-base"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle className="text-xl">Edit Student</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex justify-center mb-2">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={formData.photoUrl || "/placeholder.svg?height=100&width=100"} alt="Student photo" />
                  <AvatarFallback className="text-lg">
                    {formData.firstName && formData.lastName
                      ? getInitials(formData.firstName, formData.lastName)
                      : "ST"}
                  </AvatarFallback>
                </Avatar>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute bottom-0 right-0 rounded-full h-8 w-8"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                </Button>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-firstName" className="text-base font-medium">
                  First Name
                </Label>
                <Input
                  id="edit-firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  className="text-base h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-middleName" className="text-base font-medium">
                  Middle Name
                </Label>
                <Input
                  id="edit-middleName"
                  name="middleName"
                  value={formData.middleName}
                  onChange={handleInputChange}
                  className="text-base h-11"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-lastName" className="text-base font-medium">
                Last Name
              </Label>
              <Input
                id="edit-lastName"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                className="text-base h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-studentId" className="text-base font-medium">
                Student ID
              </Label>
              <Input
                id="edit-studentId"
                name="studentId"
                value={formData.studentId}
                onChange={handleInputChange}
                className="text-base h-11"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-yearLevel" className="text-base font-medium">
                  Year Level
                </Label>
                <Select value={formData.yearLevel} onValueChange={(value) => handleSelectChange("yearLevel", value)}>
                  <SelectTrigger className="text-base h-11">
                    <SelectValue placeholder="Select Year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1st" className="text-base">
                      1st Year
                    </SelectItem>
                    <SelectItem value="2nd" className="text-base">
                      2nd Year
                    </SelectItem>
                    <SelectItem value="3rd" className="text-base">
                      3rd Year
                    </SelectItem>
                    <SelectItem value="4th" className="text-base">
                      4th Year
                    </SelectItem>
                    <SelectItem value="5th" className="text-base">
                      5th Year
                    </SelectItem>
                    <SelectItem value="Graduate" className="text-base">
                      Graduate
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-course" className="text-base font-medium">
                  Course
                </Label>
                <Input
                  id="edit-course"
                  name="course"
                  value={formData.course}
                  onChange={handleInputChange}
                  className="text-base h-11"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status" className="text-base font-medium">
                Status
              </Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                <SelectTrigger className="text-base h-11">
                  <SelectValue placeholder="Select Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active" className="text-base">
                    Active
                  </SelectItem>
                  <SelectItem value="inactive" className="text-base">
                    Inactive
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                resetForm()
                setIsEditDialogOpen(false)
              }}
              className="text-base"
            >
              Cancel
            </Button>
            <Button onClick={handleUpdateStudent} className="text-base">
              Update Student
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isQRDialogOpen} onOpenChange={setIsQRDialogOpen}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle className="text-xl">Student QR Code</DialogTitle>
          </DialogHeader>
          {currentStudent && (
            <div className="py-4 flex flex-col items-center">
              <Avatar className="h-20 w-20 mb-3">
                <AvatarImage
                  src={currentStudent.photoUrl}
                  alt={`${currentStudent.firstName} ${currentStudent.lastName}`}
                />
                <AvatarFallback className="text-lg">
                  {getInitials(currentStudent.firstName, currentStudent.lastName)}
                </AvatarFallback>
              </Avatar>
              <h3 className="font-medium text-xl mb-4">{`${currentStudent.lastName}, ${currentStudent.firstName} ${currentStudent.middleName ? currentStudent.middleName.charAt(0) + "." : ""}`}</h3>
              <QRCodeGenerator
                value={currentStudent.studentId}
                label={`${currentStudent.firstName} ${currentStudent.lastName}`}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

