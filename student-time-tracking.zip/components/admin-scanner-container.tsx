"use client"

import { useState, useEffect } from "react"
import dynamic from "next/dynamic"

// Dynamically import QRScanner with SSR disabled to avoid hydration issues
const QRScanner = dynamic(() => import("@/components/qr-scanner"), {
  ssr: false,
})

export default function AdminScannerContainer() {
  const [isClient, setIsClient] = useState(false)

  // Use useEffect to ensure we're on the client side
  useEffect(() => {
    setIsClient(true)
  }, [])

  return <>{isClient && <QRScanner />}</>
}

